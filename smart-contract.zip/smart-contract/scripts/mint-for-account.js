const { ethers } = require("hardhat");

async function main() {
  // Get the account index from command line arguments (default to 1)
  const accountIndex = process.argv[2] ? parseInt(process.argv[2]) : 1;
  
  // Get the account
  const signers = await ethers.getSigners();
  if (accountIndex >= signers.length) {
    throw new Error(`Account index ${accountIndex} is out of range. Max: ${signers.length - 1}`);
  }
  
  const account = signers[accountIndex];
  const userAddress = await account.getAddress();
  
  console.log(`Minting ORO tokens for Account #${accountIndex} (${userAddress})...`);
  
  // Connect to deployed ORO contract
  const oroAddress = "0x0165878A594ca255338adfa4d48449f69242Eb8F";
  const ORO = await ethers.getContractFactory("ORO");
  const oro = await ORO.attach(oroAddress);
  
  // Check initial balance
  const initialBalance = await oro.balanceOf(userAddress);
  console.log(`Initial ORO balance: ${ethers.formatEther(initialBalance)} ORO`);
  
  // Each account needs a specific nullifier hash and signature
  // For Account #1, we use the values generated previously
  let nullifierHash, signature;
  
  if (accountIndex === 1) {
    nullifierHash = 123456790; // 123456789 + 1
    signature = "0x9989ddf264fec114352c450eb39e03ba01733f046b7ec474e15b1c9b7f46df9417ddf6d143b0fd271c22794ef5897fac990fb3a5e88eb040456a9f45f7fc5bdb1c";
  } else {
    // For other accounts, we would need to generate signatures separately
    // and hardcode them here, or generate them dynamically
    throw new Error(`No signature data available for Account #${accountIndex}. Please generate one first.`);
  }
  
  console.log("Minting tokens...");
  try {
    // Call mint function with the account
    const tx = await oro.connect(account).mint(nullifierHash, signature);
    console.log(`Transaction hash: ${tx.hash}`);
    
    // Wait for confirmation
    console.log("Waiting for transaction confirmation...");
    const receipt = await tx.wait();
    console.log(`Transaction confirmed in block ${receipt.blockNumber}`);
    
    // Check updated balance
    const newBalance = await oro.balanceOf(userAddress);
    console.log(`\nNew ORO balance: ${ethers.formatEther(newBalance)} ORO`);
    console.log(`Minted: ${ethers.formatEther(newBalance - initialBalance)} ORO`);
    
    console.log("\nMinting successful! ✅");
  } catch (error) {
    console.error("Error minting tokens:", error.message);
    if (error.message.includes("ORO__InvalidSignature")) {
      console.log("\nThe signature verification failed. This could be because:");
      console.log("1. The message sender doesn't match the address in the signature");
      console.log("2. The backend signer address in the contract doesn't match the one that generated the signature");
      console.log("3. The nullifier hash doesn't match the one used to generate the signature");
    }
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
}); 