const { ethers } = require("hardhat");

async function main() {
  console.log("Minting ORO tokens...");
  
  // Connect to deployed ORO contract
  const oroAddress = "0x0165878A594ca255338adfa4d48449f69242Eb8F";
  const ORO = await ethers.getContractFactory("ORO");
  const oro = await ORO.attach(oroAddress);
  
  // Use the first account to mint tokens
  const [signer] = await ethers.getSigners();
  const userAddress = await signer.getAddress();
  console.log(`User address: ${userAddress}`);
  
  // Check initial balance
  const initialBalance = await oro.balanceOf(userAddress);
  console.log(`Initial ORO balance: ${ethers.formatEther(initialBalance)} ORO`);
  
  // Nullifier hash and signature generated previously
  const nullifierHash = 123456789;
  const signature = "0x1a628ca425465b0905c23a783c8a8e7a3af009cae78588865171cf3f135f1fbe184fc80d2cd58265b07de8487ba180306ff7739358a5ceb64736b240da38ecad1c";
  
  console.log("Minting tokens...");
  try {
    // Call mint function
    const tx = await oro.mint(nullifierHash, signature);
    console.log(`Transaction hash: ${tx.hash}`);
    
    // Wait for confirmation
    console.log("Waiting for transaction confirmation...");
    const receipt = await tx.wait();
    console.log(`Transaction confirmed in block ${receipt.blockNumber}`);
    
    // Check updated balance
    const newBalance = await oro.balanceOf(userAddress);
    console.log(`\nNew ORO balance: ${ethers.formatEther(newBalance)} ORO`);
    console.log(`Minted: ${ethers.formatEther(newBalance - initialBalance)} ORO`);
    
    console.log("\nMinting successful! ✅");
  } catch (error) {
    console.error("Error minting tokens:", error.message);
    if (error.message.includes("ORO__InvalidSignature")) {
      console.log("\nThe signature verification failed. This could be because:");
      console.log("1. The message sender doesn't match the address in the signature");
      console.log("2. The backend signer address in the contract doesn't match the one that generated the signature");
      console.log("3. The nullifier hash doesn't match the one used to generate the signature");
    }
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
}); 